import json

fav_film = {
    "name":"Arcane",
    "seasons":1,
    "episodes":9,
    "heroine":"Vi",
    "released":2021
}


out_file = open("z12.json", "w")

json.dump(fav_film, out_file, indent = 4)
  
out_file.close()
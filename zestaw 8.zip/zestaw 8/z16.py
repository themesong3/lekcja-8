import json

def new_student(id, f_name, l_name):
    s = {
        "id":id,
        "f_name": f_name,
        "l_name": l_name
    }
    return s

with open("students.json") as inFile:
    data = json.load(inFile)

wrapper = []

with open("limited.json", "a") as outFile:
    for student in data:
        wrapper.append(new_student(student['id'], student['first_name'], student['last_name']))
    json.dump(wrapper, outFile, indent = 4)
        

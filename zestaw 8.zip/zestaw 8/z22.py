import my_queue as q

q.push(1)
q.push(2)

q.display()

q.pop()

q.display()

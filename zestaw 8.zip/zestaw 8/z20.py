import stack

n = int(input("What is your number ? "))

while n != 0:
    stack.push(str(n%2))
    n //= 2

result = ""
for i in stack.stack:
    result += i
if result == "":
    print("0")
else:
    print(f"Binary number = {result[::-1]}")
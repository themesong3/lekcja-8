q = []

# add value to the end of the line
def push(x):
    q.append(x)
    
# retrieve value from beginning of queue    
def pop():
    if not empty():
        return q.pop(0)
    else:
        return None
    
# return true if the queue is empty
def empty():
    return len(q) == 0

# display queue
def display():
    for i in range(len(q)):
        print(q[i])
    print()

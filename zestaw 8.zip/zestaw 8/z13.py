import json

student = {
    "name":"Alexander",
    "surname":"Ottaway - Kasperek",
    "age": 20,
    "university":"UEK",
    "year": 1,
    "weekend-studies": True,
    "hobbies":[
        "swimming",
        "mma",
        "gym",
        "programming",
        "edditing",
        "gaming"
    ]
}

outFile = open("student.json", "w")
json.dump(student, outFile, indent = 4)
outFile.close()
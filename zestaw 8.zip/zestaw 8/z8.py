person = {
    "name": "Marek",
    "surname": "Banach",
    "age": 25,
    "hobby": ["swimming","excursions"],
    "married": True,
    "phone":{"landline":"123444321","mobile":"777888999"}
   }

#a
for k in person:
    print(f"{k} --> {person[k]}")

#b
print(person['name'])

#c
for v in person['hobby']:
    print(f"Hobbie: {v}")

#d
person['surname'] = "Nowak"
print(person['surname'])

#e
person['surname'] = False

#f
person['gender'] = "male"
print(person['gender'])
#g
person['hobby'].append("bicycle")
for v in person['hobby']:
    print(f"Hobbie: {v}")

#h
person['phone']['workphone'] = "313131444"
print(person['phone'])
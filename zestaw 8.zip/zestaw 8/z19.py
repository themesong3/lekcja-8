import stack

#a
stack.display()

#b
stack.push(2)

#c
stack.push(14)

#d
stack.push(9)

#e
stack.display()

#f
stack.pop()

#g
stack.display()

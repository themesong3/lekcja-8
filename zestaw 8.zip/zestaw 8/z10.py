countries = [
    {"France":"6923659"},
    {"Germany":"346735734"},
    {"Poland":"2745544"},
    {"USA":"3462727"},
    {"Canda":"3465729649"}
]

for obj in countries:
    for k, v in obj.items():
        print(f"{k}:{v}")


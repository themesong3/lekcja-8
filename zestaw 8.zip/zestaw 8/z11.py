import json

with open("cars.json") as file:
    data = json.load(file)

for item in data:
    print('\n')
    for k, v in item.items():
        print(f"{k}:{v}")
import stack
sym = ""
while sym != "=":
    sym = input("Podaj liczbe lub znak: ")
    if sym.isnumeric():
        stack.push(sym)
    elif sym == "+" or sym == "-" or sym == "*" or sym == "/":
        x = stack.pop()
        y = stack.pop()
        z = f"{x}{sym}{y}"
        stack.push(str(eval(z)))
    else:
        continue
print(f"Result is: {stack.pop()}")

phone = {
    "brand": "Apple",
    "model": "iPhone 6",
    "year": 2014,
    "price_pln":  890,
    "color": "gold",
    "cameras": 1
}

print(phone.items())